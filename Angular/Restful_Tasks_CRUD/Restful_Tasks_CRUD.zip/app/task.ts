export class Task {
    title: string = "";
    description: string = "";
    completed: boolean = false;
}
